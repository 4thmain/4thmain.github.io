# India Privacy Monitor
Tracker for public projects relating to privacy and surveillance in India.

## Research
Research by Maria Xynou, Assistance by Srinivas Atreya
[Centre for Internet & Society, Bangalore](http://cis-india.org)

###

## Development
Design and Code by Arun Ganesh
[Studio 4th Main](http://4thmain.github.io)

### Credits
* [Fingerprint](http://thenounproject.com/noun/fingerprint/#icon-No1803) designed by Andrew Forrester from The Noun Project 
* [Crime](http://thenounproject.com/noun/crime/#icon-No8847) designed by Eden Clairicia from The Noun Project